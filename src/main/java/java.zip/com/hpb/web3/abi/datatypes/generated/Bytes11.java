package com.hpb.web3.abi.datatypes.generated;

import com.hpb.web3.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use com.hpb.web3.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes11 extends Bytes {
    public static final Bytes11 DEFAULT = new Bytes11(new byte[11]);

    public Bytes11(byte[] value) {
        super(11, value);
    }
}
