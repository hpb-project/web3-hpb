package com.hpb.web3.abi.datatypes.generated;

import com.hpb.web3.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use com.hpb.web3.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes9 extends Bytes {
    public static final Bytes9 DEFAULT = new Bytes9(new byte[9]);

    public Bytes9(byte[] value) {
        super(9, value);
    }
}
