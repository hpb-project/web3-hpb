package com.hpb.web3.abi.datatypes.generated;

import com.hpb.web3.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use com.hpb.web3.codegen.AbiTypesGenerator in the 
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes6 extends Bytes {
    public static final Bytes6 DEFAULT = new Bytes6(new byte[6]);

    public Bytes6(byte[] value) {
        super(6, value);
    }
}
