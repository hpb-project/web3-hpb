package com.hpb.web3.rlp;

/**
 * Base RLP type.
 */
public interface RlpType {
}
