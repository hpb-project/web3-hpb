package com.hpb.web3.protocol.core.methods.response;

import com.hpb.web3.protocol.core.Response;

/**
 * net_version.
 */
public class NetVersion extends Response<String> {
    public String getNetVersion() {
        return getResult();
    }
}
