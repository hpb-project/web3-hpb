package com.hpb.web3.protocol.core.methods.response;

import java.util.List;

import com.hpb.web3.protocol.core.Response;

/**
 * eth_getCompilers.
 */
public class EthGetCompilers extends Response<List<String>> {
    public List<String> getCompilers() {
        return getResult();
    }
}
