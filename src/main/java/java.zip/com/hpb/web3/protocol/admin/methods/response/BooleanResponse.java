package com.hpb.web3.protocol.admin.methods.response;

import com.hpb.web3.protocol.core.Response;

/**
 * Boolean response type.
 */
public class BooleanResponse extends Response<Boolean> {
    public boolean success() {
        return getResult();
    }
}
