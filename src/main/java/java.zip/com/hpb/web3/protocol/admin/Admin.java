package com.hpb.web3.protocol.admin;

import java.math.BigInteger;

import com.hpb.web3.protocol.Web3j;
import com.hpb.web3.protocol.Web3jService;
import com.hpb.web3.protocol.admin.methods.response.NewAccountIdentifier;
import com.hpb.web3.protocol.admin.methods.response.PersonalListAccounts;
import com.hpb.web3.protocol.admin.methods.response.PersonalUnlockAccount;
import com.hpb.web3.protocol.core.Request;
import com.hpb.web3.protocol.core.methods.request.Transaction;
import com.hpb.web3.protocol.core.methods.response.EthSendTransaction;

/**
 * JSON-RPC Request object building factory for common Parity and Geth. 
 */
public interface Admin extends Web3j {

    static Admin build(Web3jService web3jService) {
        return new JsonRpc2_0Admin(web3jService);
    }
    
    public Request<?, PersonalListAccounts> personalListAccounts();
    
    public Request<?, NewAccountIdentifier> personalNewAccount(String password);
    
    public Request<?, PersonalUnlockAccount> personalUnlockAccount(
            String address, String passphrase, BigInteger duration);
    
    public Request<?, PersonalUnlockAccount> personalUnlockAccount(
            String address, String passphrase);
    
    public Request<?, EthSendTransaction> personalSendTransaction(
            Transaction transaction, String password);

}   
