package com.hpb.web3.tuples;

/**
 * Tuple abstraction.
 */
public interface Tuple {

    int getSize();
}
