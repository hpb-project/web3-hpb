package com.hpb.web3.tuples;

/**
 * Empty Tuple type.
 */
public class EmptyTuple implements Tuple {

    @Override
    public int getSize() {
        return 0;
    }
}
